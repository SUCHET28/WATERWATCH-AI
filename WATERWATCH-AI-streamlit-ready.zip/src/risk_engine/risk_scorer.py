"""
Community Risk Scoring and Water Quality Index (WQI) Calculation Engine.
Calculates parameter-level deviations from WHO/EPA drinking water standards
and outputs actionable municipal/community alerts and remediation steps.
"""

from typing import Dict, Any, List
import numpy as np
from ..data.loader import PARAMETER_GUIDELINES, FEATURE_NAMES

# Parameter risk weights based on toxicological severity
PARAMETER_WEIGHTS = {
    "ph": 0.12,
    "Hardness": 0.08,
    "Solids": 0.10,
    "Chloramines": 0.14,
    "Sulfate": 0.12,
    "Conductivity": 0.08,
    "Organic_carbon": 0.12,
    "Trihalomethanes": 0.14,
    "Turbidity": 0.10
}


def audit_parameter(param: str, value: float) -> Dict[str, Any]:
    """Audits a single water quality measurement against WHO/EPA guidelines."""
    guideline = PARAMETER_GUIDELINES.get(param)
    if not guideline:
        return {"status": "Unknown", "severity": 0, "message": "No guideline available"}

    if value is None or np.isnan(value):
        return {
            "parameter": param,
            "label": guideline["label"],
            "unit": guideline["unit"],
            "value": "Missing (NaN)",
            "status": "Warning",
            "badge": "⚠️ Imputed",
            "severity": 1,
            "violation": False,
            "message": "Missing value — automatically imputed with dataset median during inference.",
            "remediation": "Collect a fresh sample to verify this specific parameter."
        }

    val = float(value)
    min_safe = guideline["min_safe"]
    max_safe = guideline["max_safe"]

    if min_safe <= val <= max_safe:
        return {
            "parameter": param,
            "label": guideline["label"],
            "unit": guideline["unit"],
            "value": round(val, 2),
            "status": "Safe",
            "badge": "✅ Safe",
            "severity": 0,
            "violation": False,
            "message": f"Within safe guideline bounds ({min_safe} - {max_safe} {guideline['unit']}).",
            "remediation": "Regular routine monitoring."
        }

    # Evaluate deviation ratio
    if val < min_safe:
        ratio = (min_safe - val) / max(min_safe, 1.0)
        direction = "Low"
    else:
        ratio = (val - max_safe) / max(max_safe, 1.0)
        direction = "High"

    severity = 3 if ratio >= 0.5 else 2
    status = "Critical" if severity == 3 else "Warning"
    badge = "🔴 Critical" if severity == 3 else "🟠 Warning"

    # Specific remediation advice
    remediation_map = {
        "ph": "Acidic: Add soda ash/lime; Alkaline: Acidic buffer dosing or carbon dioxide sparging.",
        "Hardness": "Use water softeners (ion exchange resins) or reverse osmosis.",
        "Solids": "Install multi-stage Reverse Osmosis (RO) or electrodialysis system.",
        "Chloramines": "Apply activated carbon filtration, sodium thiosulfate neutralizers, or UV irradiation.",
        "Sulfate": "Deploy reverse osmosis, distillation, or strong-base anion exchange resins.",
        "Conductivity": "Desalination or demineralization via deionization / reverse osmosis.",
        "Organic_carbon": "Advanced oxidation processes (AOPs), ozone-biofiltration, or Granular Activated Carbon (GAC).",
        "Trihalomethanes": "Immediate Granular Activated Carbon (GAC) filtration, packed-tower aeration; optimize chlorination.",
        "Turbidity": "Coagulation, flocculation, settling basin, and rapid sand/membrane filtration."
    }

    return {
        "parameter": param,
        "label": guideline["label"],
        "unit": guideline["unit"],
        "value": round(val, 2),
        "status": status,
        "badge": badge,
        "severity": severity,
        "violation": True,
        "message": f"{direction} ({val:.1f} vs safe max {max_safe} {guideline['unit']}). {guideline['health_impact']}",
        "remediation": remediation_map.get(param, "Standard municipal treatment.")
    }


def calculate_community_risk(sample_dict: Dict[str, Any], model_prediction: int, prob_potable: float) -> Dict[str, Any]:
    """
    Computes an aggregated Community Risk Score (0 to 100), composite index tier,
    and structured screening advisories for health departments and local communities.
    """
    audits = []
    total_weighted_penalty = 0.0
    critical_violations = 0
    warning_violations = 0

    for param in FEATURE_NAMES:
        val = sample_dict.get(param, np.nan)
        audit = audit_parameter(param, val)
        audits.append(audit)

        w = PARAMETER_WEIGHTS.get(param, 0.1)
        if audit["severity"] == 3:
            critical_violations += 1
            total_weighted_penalty += w * 100.0
        elif audit["severity"] == 2:
            warning_violations += 1
            total_weighted_penalty += w * 50.0
        elif audit["severity"] == 1:
            total_weighted_penalty += w * 20.0

    # Combine chemical violation score with ML model non-potability probability
    ml_risk_component = (1.0 - prob_potable) * 100.0
    
    # 60% chemical standard violation + 40% ML probability
    combined_risk_score = (0.60 * total_weighted_penalty) + (0.40 * ml_risk_component)
    combined_risk_score = min(max(combined_risk_score, 0.0), 100.0)

    # Determine risk category
    if critical_violations >= 2 or combined_risk_score >= 65:
        risk_level = "CRITICAL RISK"
        risk_color = "#e63946"
        advisory = (
            "🚨 DO NOT CONSUME. High levels of chemical non-compliance detected. "
            "Issue immediate boil/filtration warning and dispatch mobile water testing lab."
        )
        action_priority = "Priority 1: Immediate Source Closure & Community Alert"
    elif model_prediction == 0 or combined_risk_score >= 40:
        risk_level = "HIGH RISK"
        risk_color = "#f77f00"
        advisory = (
            "⚠️ UNSAFE FOR DIRECT DRINKING. One or more parameters exceed permissible drinking thresholds. "
            "Requires point-of-use filtration, flocculation, or reverse osmosis treatment before use."
        )
        action_priority = "Priority 2: Water Treatment & Follow-up Laboratory Assay"
    elif warning_violations >= 1 or combined_risk_score >= 20:
        risk_level = "MODERATE RISK"
        risk_color = "#fcbf49"
        advisory = (
            "⚡ CAUTIONARY MONITORING. Minor guideline variance detected. "
            "Sample is borderline; recommended for secondary filtration and routine microbial culture test."
        )
        action_priority = "Priority 3: Secondary Filtration & Scheduled Audit"
    else:
        risk_level = "LOW RISK (PRELIMINARY PASS)"
        risk_color = "#2a9d8f"
        advisory = (
            "✅ PRELIMINARY PASS. Physicochemical values align with normal guidelines. "
            "Note: Does not test for biological pathogens (E. coli) or heavy metals (lead, arsenic). Lab assay required."
        )
        action_priority = "Priority 4: Routine Maintenance"

    return {
        "risk_score": round(combined_risk_score, 1),
        "risk_level": risk_level,
        "risk_color": risk_color,
        "advisory": advisory,
        "action_priority": action_priority,
        "critical_violations": critical_violations,
        "warning_violations": warning_violations,
        "parameter_audits": audits
    }
