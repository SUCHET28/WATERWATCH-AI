"""Models package for WATERWATCH AI."""
from .predictor import WaterWatchPredictor, MODEL_METADATA
