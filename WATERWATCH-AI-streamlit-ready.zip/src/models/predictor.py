"""
Model loading and inference services for WATERWATCH AI.
"""

from pathlib import Path
from typing import Dict, Any, Tuple, Optional
import joblib
import numpy as np
import pandas as pd
from ..data.loader import FEATURE_NAMES

MODEL_METADATA = {
    "decision_tree": {
        "name": "Decision Tree Classifier",
        "filename": "decision_tree_pipeline.joblib",
        "description": "Regularized tree (max_depth=6, min_samples_leaf=10) with internal median imputer.",
        "test_accuracy": 0.6311,
        "cv_accuracy": "0.6298 ± 0.0095",
        "cv_f1_macro": "0.5192 ± 0.0307",
        "roc_auc": 0.6011,
        "dangerous_errors": 53,
        "dangerous_error_rate": "13.25%",
        "best_for": "Interpretable rule-based decision trees with explicit threshold splits."
    },
    "gaussian_nb": {
        "name": "Gaussian Naive Bayes",
        "filename": "gaussian_nb_pipeline.joblib",
        "description": "Probabilistic Bayesian classifier with median imputer and standard scaler.",
        "test_accuracy": 0.6143,
        "cv_accuracy": "0.6275 ± 0.0074",
        "cv_f1_macro": "0.5393 ± 0.0129",
        "roc_auc": 0.6090,
        "dangerous_errors": 45,
        "dangerous_error_rate": "11.25%",
        "best_for": "Smooth probabilistic likelihood estimation and higher sensitivity."
    }
}


def find_model_path(filename: str) -> Path:
    """Locates a model file across potential relative or absolute directory structures."""
    candidates = [
        Path(f"models/{filename}"),
        Path(f"../models/{filename}"),
        Path(f"WATERWATCH-AI/models/{filename}"),
        Path(r"C:\Users\Varun\.gemini\antigravity\scratch\WATERWATCH-AI\models") / filename
    ]
    for p in candidates:
        if p.exists():
            return p.resolve()
    return candidates[0]


class WaterWatchPredictor:
    """Wrapper for trained Scikit-Learn pipelines supporting single and batch inference."""

    _models = {}

    @classmethod
    def load_pipeline(cls, model_key: str):
        """Loads and caches the requested pipeline."""
        if model_key not in cls._models:
            meta = MODEL_METADATA.get(model_key)
            if not meta:
                raise ValueError(f"Unknown model key '{model_key}'. Expected one of {list(MODEL_METADATA.keys())}")
            
            filepath = find_model_path(meta["filename"])
            if not filepath.exists():
                raise FileNotFoundError(f"Model file not found at {filepath}")
            
            cls._models[model_key] = joblib.load(filepath)
        return cls._models[model_key]

    @classmethod
    def predict_sample(cls, sample_dict: Dict[str, Any], model_key: str = "decision_tree") -> Dict[str, Any]:
        """
        Runs inference on a single dictionary of features.
        Missing values (None / NaN) are preserved and imputed by the internal pipeline step.
        """
        pipeline = cls.load_pipeline(model_key)
        
        # Ensure exact 9 feature order
        ordered_data = {feat: [sample_dict.get(feat, np.nan)] for feat in FEATURE_NAMES}
        df_sample = pd.DataFrame(ordered_data)

        pred_class = int(pipeline.predict(df_sample)[0])
        probabilities = pipeline.predict_proba(df_sample)[0]
        prob_non_potable = float(probabilities[0])
        prob_potable = float(probabilities[1])

        label = "Potable (Safe for Consumption)" if pred_class == 1 else "Non-Potable (Unsafe / Contaminated)"

        return {
            "prediction_class": pred_class,
            "label": label,
            "is_potable": bool(pred_class == 1),
            "prob_potable": prob_potable,
            "prob_non_potable": prob_non_potable,
            "confidence": prob_potable if pred_class == 1 else prob_non_potable,
            "model_used": MODEL_METADATA[model_key]["name"],
            "model_key": model_key,
            "dangerous_error_warning": MODEL_METADATA[model_key]["dangerous_error_rate"]
        }

    @classmethod
    def predict_batch(cls, df: pd.DataFrame, model_key: str = "decision_tree") -> pd.DataFrame:
        """
        Runs inference on an entire batch dataframe.
        Returns a new dataframe with predictions, probabilities, and risk classifications.
        """
        pipeline = cls.load_pipeline(model_key)

        # Validate that all required features are present
        missing_cols = [c for c in FEATURE_NAMES if c not in df.columns]
        if missing_cols:
            raise ValueError(f"Input DataFrame is missing required columns: {missing_cols}")

        df_input = df[FEATURE_NAMES].copy()
        
        preds = pipeline.predict(df_input)
        probas = pipeline.predict_proba(df_input)

        result_df = df.copy()
        result_df["Predicted_Class"] = preds
        result_df["Potability_Label"] = np.where(preds == 1, "Potable", "Non-Potable")
        result_df["Potable_Probability"] = np.round(probas[:, 1], 4)
        result_df["NonPotable_Probability"] = np.round(probas[:, 0], 4)

        return result_df
