"""Data package for WATERWATCH AI."""
from .loader import FEATURE_NAMES, TARGET_COL, PARAMETER_GUIDELINES, PRESET_SAMPLES, load_dataset
