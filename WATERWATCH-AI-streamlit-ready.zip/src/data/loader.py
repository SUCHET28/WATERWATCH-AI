"""
Data loading and parameter guideline specifications for WATERWATCH AI.
"""

from pathlib import Path
import pandas as pd
import numpy as np

# Exact feature list and order required by the serialized ML pipelines
FEATURE_NAMES = [
    "ph",
    "Hardness",
    "Solids",
    "Chloramines",
    "Sulfate",
    "Conductivity",
    "Organic_carbon",
    "Trihalomethanes",
    "Turbidity",
]

TARGET_COL = "Potability"

# WHO / EPA Drinking Water Quality Guidelines & Tolerances
PARAMETER_GUIDELINES = {
    "ph": {
        "label": "pH Level",
        "unit": "pH units",
        "min_safe": 6.5,
        "max_safe": 8.5,
        "min_limit": 0.0,
        "max_limit": 14.0,
        "step": 0.1,
        "default": 7.2,
        "desc": "Measures water acidity / alkalinity. WHO standard range is 6.5 to 8.5.",
        "health_impact": "Values <6.5 can cause corrosion of pipes and heavy metal leaching; values >8.5 produce scaling and bitter taste."
    },
    "Hardness": {
        "label": "Hardness",
        "unit": "mg/L (CaCO3)",
        "min_safe": 60.0,
        "max_safe": 200.0,
        "min_limit": 40.0,
        "max_limit": 350.0,
        "step": 1.0,
        "default": 195.0,
        "desc": "Capacity of water to precipitate soap; caused primarily by Calcium and Magnesium ions.",
        "health_impact": "Desirable drinking limit is <200 mg/L. High hardness (>300 mg/L) causes encrustation in water supplies and kidney stress."
    },
    "Solids": {
        "label": "Total Dissolved Solids (TDS)",
        "unit": "ppm",
        "min_safe": 100.0,
        "max_safe": 1000.0,
        "min_limit": 300.0,
        "max_limit": 60000.0,
        "step": 100.0,
        "default": 18000.0,
        "desc": "Mineral, salt, and organic matter dissolved in water.",
        "health_impact": "WHO considers TDS <500 ppm desirable and <1000 ppm acceptable. High TDS gives unpalatable mineral taste."
    },
    "Chloramines": {
        "label": "Chloramines",
        "unit": "ppm",
        "min_safe": 0.5,
        "max_safe": 4.0,
        "min_limit": 0.0,
        "max_limit": 15.0,
        "step": 0.1,
        "default": 7.1,
        "desc": "Disinfectant compounds created by combining chlorine and ammonia.",
        "health_impact": "EPA maximum residual disinfectant level goal is 4.0 ppm. High levels cause eye/nose irritation and stomach discomfort."
    },
    "Sulfate": {
        "label": "Sulfate",
        "unit": "mg/L",
        "min_safe": 0.0,
        "max_safe": 250.0,
        "min_limit": 100.0,
        "max_limit": 500.0,
        "step": 1.0,
        "default": 330.0,
        "desc": "Naturally occurring mineral found in minerals, soil, and rocks.",
        "health_impact": "WHO guideline recommendation is <250 mg/L. Concentrations >500 mg/L induce acute laxative effects and dehydration."
    },
    "Conductivity": {
        "label": "Electrical Conductivity",
        "unit": "μS/cm",
        "min_safe": 50.0,
        "max_safe": 500.0,
        "min_limit": 100.0,
        "max_limit": 800.0,
        "step": 5.0,
        "default": 420.0,
        "desc": "Measures the electric current conduction, which reflects dissolved ionic mineral content.",
        "health_impact": "WHO standard generally advises <400-500 μS/cm for potable tap supplies. Elevated conductivity indicates mineral pollution."
    },
    "Organic_carbon": {
        "label": "Total Organic Carbon (TOC)",
        "unit": "ppm",
        "min_safe": 0.0,
        "max_safe": 10.0,
        "min_limit": 2.0,
        "max_limit": 30.0,
        "step": 0.1,
        "default": 14.2,
        "desc": "Total amount of carbon found in an organic compound.",
        "health_impact": "US EPA drinking limit is <2-4 ppm for treated water and <10 ppm for raw source water. Higher TOC forms carcinogenic disinfection byproducts."
    },
    "Trihalomethanes": {
        "label": "Trihalomethanes (THMs)",
        "unit": "μg/L (ppb)",
        "min_safe": 0.0,
        "max_safe": 80.0,
        "min_limit": 0.0,
        "max_limit": 130.0,
        "step": 0.5,
        "default": 65.0,
        "desc": "Chemical byproducts formed when chlorine reacts with organic matter in water.",
        "health_impact": "WHO / EPA standard limit is 80 μg/L. Chronic exposure above 80 μg/L increases risk of bladder and colorectal cancer."
    },
    "Turbidity": {
        "label": "Turbidity",
        "unit": "NTU",
        "min_safe": 0.0,
        "max_safe": 5.0,
        "min_limit": 1.0,
        "max_limit": 7.0,
        "step": 0.1,
        "default": 3.8,
        "desc": "Measurement of water clarity and cloudiness caused by suspended solids.",
        "health_impact": "WHO standard recommends <1 NTU (acceptable up to 5 NTU). High turbidity shields microbes from disinfection."
    }
}

# Standard sample presets for quick demonstration
PRESET_SAMPLES = {
    "🌱 Clean Municipal Tap Water (Normal)": {
        "ph": 7.3,
        "Hardness": 180.0,
        "Solids": 8500.0,
        "Chloramines": 3.2,
        "Sulfate": 240.0,
        "Conductivity": 380.0,
        "Organic_carbon": 6.5,
        "Trihalomethanes": 45.0,
        "Turbidity": 2.1
    },
    "⚠️ High Sulfate & Mineral Contamination": {
        "ph": 7.9,
        "Hardness": 245.0,
        "Solids": 34000.0,
        "Chloramines": 7.8,
        "Sulfate": 420.0,
        "Conductivity": 580.0,
        "Organic_carbon": 17.5,
        "Trihalomethanes": 88.0,
        "Turbidity": 4.6
    },
    "☢️ Acidic Runoff with High Organic Matter": {
        "ph": 4.2,
        "Hardness": 280.0,
        "Solids": 26000.0,
        "Chloramines": 9.4,
        "Sulfate": 390.0,
        "Conductivity": 620.0,
        "Organic_carbon": 22.0,
        "Trihalomethanes": 105.0,
        "Turbidity": 5.8
    },
    "🏔️ Untreated Highland Spring (Missing Sulfate)": {
        "ph": 6.8,
        "Hardness": 140.0,
        "Solids": 12000.0,
        "Chloramines": 4.5,
        "Sulfate": np.nan,  # tests automated median imputation
        "Conductivity": 320.0,
        "Organic_carbon": 8.0,
        "Trihalomethanes": 52.0,
        "Turbidity": 3.2
    }
}


def find_data_file() -> Path:
    """Finds the dataset file in either data/ or data/raw/."""
    candidates = [
        Path("data/water_potability.csv"),
        Path("data/raw/water_potability.csv"),
        Path("../data/water_potability.csv"),
        Path("../data/raw/water_potability.csv"),
    ]
    for c in candidates:
        if c.exists():
            return c.resolve()
    # Fallback absolute path
    abs_fallback = Path(r"C:\Users\Varun\.gemini\antigravity\scratch\WATERWATCH-AI\data\water_potability.csv")
    if abs_fallback.exists():
        return abs_fallback
    return candidates[0]


def load_dataset() -> pd.DataFrame:
    """Loads the water potability dataset."""
    filepath = find_data_file()
    if not filepath.exists():
        raise FileNotFoundError(f"Could not locate water_potability.csv at {filepath}")
    return pd.read_csv(filepath)
