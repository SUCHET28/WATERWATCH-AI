"""
WATERWATCH AI — Model Benchmark & Screening Audit Dashboard
Benchmarking supervised classifiers, 5-fold cross validation, and dangerous false positive auditing.
"""

import sys
import json
from pathlib import Path

# Add project root and app directory to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
APP_DIR = Path(__file__).resolve().parent.parent
for p in [str(ROOT_DIR), str(APP_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from src.components.ui_elements import render_metric_card, render_disclaimer

st.set_page_config(page_title="Model Benchmark — WATERWATCH AI", page_icon="🤖", layout="wide")

st.markdown("# 🤖 Model Benchmark & Public Health Screening Audit")
st.markdown("Verification of model performance across 656 held-out test samples and 5-fold stratified cross-validation.")

render_disclaimer(compact=True)

# Load evaluation data
metrics_csv = ROOT_DIR / "results" / "metrics" / "final_model_comparison.csv"
metrics_json = ROOT_DIR / "results" / "metrics" / "evaluation_summary.json"

if metrics_csv.exists():
    df_benchmark = pd.read_csv(metrics_csv)
else:
    st.error("Metrics CSV file not found in results/metrics/.")
    df_benchmark = pd.DataFrame()

# Key Benchmark Metrics Row
c1, c2, c3, c4 = st.columns(4)
with c1:
    render_metric_card("Top Test Accuracy", "63.11%", "Decision Tree Classifier", "+2.13% vs Baseline", "#2a9d8f")
with c2:
    render_metric_card("Top ROC-AUC", "0.6090", "Gaussian Naive Bayes", "Macro Discrimination", "#457b9d")
with c3:
    render_metric_card("Top Potable Recall", "26.17%", "Decision Tree (67/256)", "Dummy has 0.00%", "#f77f00")
with c4:
    render_metric_card("Dangerous Error Rate", "11.25% - 13.25%", "Unsafe Water Mispredicted Safe", "Critical Health Risk", "#e63946")

st.markdown("<br>", unsafe_allow_html=True)

# Tabs
tab_table, tab_charts, tab_matrix, tab_roc, tab_limitations = st.tabs([
    "📊 Benchmark Comparison Table",
    "📈 Comparative Performance Charts",
    "⚠️ The Dangerous Screening Error (FP)",
    "📉 ROC-AUC Analysis",
    "🔬 Model Limitations & Academic Review"
])

# ----------------- TAB 1: TABLE -----------------
with tab_table:
    st.markdown("### Certified Benchmark Comparison (Held-Out Test Set: 656 Samples)")
    if not df_benchmark.empty:
        st.dataframe(df_benchmark, use_container_width=True, hide_index=True)
        st.caption("Data source: `results/metrics/final_model_comparison.csv` and `evaluation_summary.json`.")

    st.markdown(
        """
        #### 📌 Key Takeaways from the Benchmark:
        - **The Naive Baseline (Dummy Classifier):** Achieves **60.98% accuracy** simply by predicting Class 0 for every single record, but completely fails to identify any potable water (0.00% Potable Recall, 0.5000 ROC-AUC).
        - **Gaussian Naive Bayes:** Exhibits superior ROC-AUC (0.6090) and higher Non-Potable recall (88.75%), resulting in the lowest dangerous error rate among trained models (11.25%).
        - **Decision Tree Classifier:** Yields the highest overall accuracy (63.11%) and potable recall (26.17%), capturing non-linear feature partition rules.
        """
    )

# ----------------- TAB 2: CHARTS -----------------
with tab_charts:
    st.markdown("### Comparative Performance Across Core Metrics")
    
    col_chart1, col_chart2 = st.columns(2)

    with col_chart1:
        if not df_benchmark.empty:
            fig_acc = px.bar(
                df_benchmark,
                x="Model",
                y=["Accuracy", "5-Fold CV Accuracy Mean"],
                barmode="group",
                title="Test Accuracy vs 5-Fold Cross-Validation Accuracy",
                color_discrete_sequence=["#1d3557", "#457b9d"]
            )
            fig_acc.update_layout(yaxis=dict(range=[0.5, 0.7]), height=400, paper_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig_acc, use_container_width=True)

    with col_chart2:
        if not df_benchmark.empty:
            fig_f1 = px.bar(
                df_benchmark,
                x="Model",
                y=["F1-Score (Macro)", "ROC-AUC"],
                barmode="group",
                title="Macro F1-Score and ROC-AUC Discrimination",
                color_discrete_sequence=["#2a9d8f", "#e76f51"]
            )
            fig_f1.update_layout(yaxis=dict(range=[0.3, 0.7]), height=400, paper_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig_f1, use_container_width=True)

# ----------------- TAB 3: DANGEROUS ERROR AUDIT -----------------
with tab_matrix:
    st.markdown("### ⚠️ The Dangerous Public Health Screening Error")
    st.markdown(
        """
        In toxicological screening, **False Positives (Actual Class 0 Non-Potable → Predicted Class 1 Potable)** 
        represent catastrophic errors where contaminated water is mistakenly cleared for human drinking.
        """
    )

    col_fp_info, col_fp_breakdown = st.columns([1, 1])

    with col_fp_info:
        st.markdown(
            """
            #### 🩸 Clinical & Public Health Impact:
            - **False Positive (Dangerous Error):** Contaminated water with elevated sulfate, high trihalomethanes, or heavy solids is distributed to communities, risking outbreaks of chemical gastroenteritis, heavy metal toxicosis, or chronic carcinogenic exposure.
            - **False Negative (Safe Error):** Potable water is labeled non-potable, requiring redundant filtration or lab re-testing (an economic loss, but zero human health toxicity).
            """
        )

        fp_summary = pd.DataFrame([
            {"Model": "Dummy Classifier (Baseline)", "Unsafe Samples": 400, "Dangerous False Positives": 0, "Dangerous Error Rate": "0.00% (Flags everything unsafe)"},
            {"Model": "Gaussian Naive Bayes", "Unsafe Samples": 400, "Dangerous False Positives": 45, "Dangerous Error Rate": "11.25%"},
            {"Model": "Decision Tree Classifier", "Unsafe Samples": 400, "Dangerous False Positives": 53, "Dangerous Error Rate": "13.25%"}
        ])
        st.dataframe(fp_summary, use_container_width=True, hide_index=True)

    with col_fp_breakdown:
        fig_fp = px.bar(
            fp_summary,
            x="Model",
            y="Dangerous False Positives",
            color="Model",
            title="Dangerous False-Positive Errors on 400 Unsafe Samples",
            color_discrete_sequence=["#6c757d", "#457b9d", "#e63946"],
            text="Dangerous False Positives"
        )
        fig_fp.update_layout(height=360, showlegend=False, paper_bgcolor='rgba(0,0,0,0)')
        st.plotly_chart(fig_fp, use_container_width=True)

    st.markdown("#### Confusion Matrix Plots from Member 1 Auditing")
    col_cm1, col_cm2, col_cm3 = st.columns(3)
    fig_dir = ROOT_DIR / "results" / "figures"
    
    with col_cm1:
        cm_dummy = fig_dir / "confusion_matrix_dummy_classifier.png"
        if cm_dummy.exists():
            st.image(str(cm_dummy), caption="Dummy Classifier (All Class 0)", use_container_width=True)
    with col_cm2:
        cm_gnb = fig_dir / "confusion_matrix_gaussian_nb.png"
        if cm_gnb.exists():
            st.image(str(cm_gnb), caption="Gaussian Naive Bayes (45 FP Errors)", use_container_width=True)
    with col_cm3:
        cm_dt = fig_dir / "confusion_matrix_decision_tree.png"
        if cm_dt.exists():
            st.image(str(cm_dt), caption="Decision Tree Classifier (53 FP Errors)", use_container_width=True)

# ----------------- TAB 4: ROC CURVES -----------------
with tab_roc:
    st.markdown("### Comparative Receiver Operating Characteristic (ROC-AUC)")
    roc_img = ROOT_DIR / "results" / "figures" / "comparative_roc_curves.png"
    if roc_img.exists():
        st.image(str(roc_img), caption="Comparative ROC Curves: GNB (0.6090) vs Decision Tree (0.6011) vs Baseline (0.5000)", use_container_width=True)
    else:
        st.warning("ROC curves figure not found.")

    st.info(
        "**ROC Interpretation:** The area under the ROC curve measures ranking discrimination across decision thresholds. "
        "Gaussian Naive Bayes (0.6090) and Decision Tree (0.6011) both demonstrate statistically meaningful discrimination above the random diagonal (0.5000)."
    )

# ----------------- TAB 5: LIMITATIONS -----------------
with tab_limitations:
    st.markdown("### 🔬 Rigorous Academic & Engineering Limitations")
    st.markdown(
        """
        As documented in Member 1's Technical Report and team architecture agreements:
        
        1. **Modest Discrimination Above Random Chance:**
           - ROC-AUC values (~0.60) reflect the significant intrinsic overlap in chemical distributions between potable and non-potable samples in this dataset.
           - The models cannot provide 99%+ deterministic guarantees.
        
        2. **Physicochemical Scope Boundary:**
           - The system evaluates potability **strictly from 9 continuous physicochemical parameters**.
           - **Crucial Unmeasured Factors:** Does not measure toxic heavy metals (lead, mercury, cadmium, arsenic), viral/bacterial pathogens (*E. coli*, Salmonella, Giardia), or volatile pesticides.
        
        3. **Generalization Scope:**
           - Stratified 5-fold cross-validation proves stability within this dataset distribution, but does not guarantee performance across geographically distinct groundwater basins with different mineralization profiles.
        
        4. **Mandatory Laboratory Disclaimer:**
           - WATERWATCH AI is an early screening and triage utility. Certified laboratory assays remain legally required before municipal drinking water distribution.
        """
    )
