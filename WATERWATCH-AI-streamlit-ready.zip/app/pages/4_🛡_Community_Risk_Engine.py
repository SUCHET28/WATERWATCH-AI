"""
WATERWATCH AI — Community Risk Monitoring Engine
Actionable risk scoring, municipal screening prioritization, and public health advisories.
"""

import sys
from pathlib import Path

# Add project root and app directory to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
APP_DIR = Path(__file__).resolve().parent.parent
for p in [str(ROOT_DIR), str(APP_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

import streamlit as st
import pandas as pd
import numpy as np

from src.data.loader import FEATURE_NAMES, PARAMETER_GUIDELINES, PRESET_SAMPLES
from src.models.predictor import WaterWatchPredictor
from src.risk_engine.risk_scorer import calculate_community_risk, PARAMETER_WEIGHTS
from src.components.ui_elements import (
    render_disclaimer,
    create_risk_gauge,
    create_radar_chart,
    render_metric_card
)

st.set_page_config(page_title="Community Risk Engine — WATERWATCH AI", page_icon="🛡️", layout="wide")

st.markdown("# 🛡️ Community Risk Monitoring Engine")
st.markdown("Decision-support system for municipal water boards, health officers, and community monitoring networks.")

render_disclaimer(compact=True)

# Water Source Metadata Form
st.markdown("### 📍 Water Source & Community Context")
m_col1, m_col2, m_col3 = st.columns(3)

with m_col1:
    source_name = st.text_input("Source Identifier / Station Name:", value="Community Borewell #7")
with m_col2:
    source_type = st.selectbox("Source Type:", ["Groundwater Borewell", "Municipal Supply Pipeline", "River Intake Station", "Highland Spring", "Community Storage Reservoir"])
with m_col3:
    pop_served = st.number_input("Estimated Population Dependent:", min_value=10, max_value=500000, value=2500, step=100)

st.markdown("### 🧪 Physicochemical Parameters")
preset = st.selectbox("Load Sample Presets:", ["Custom Input"] + list(PRESET_SAMPLES.keys()))

default_vals = PRESET_SAMPLES.get(preset, {})

p_col1, p_col2, p_col3 = st.columns(3)
sample_data = {}

with p_col1:
    for feat in ["ph", "Hardness", "Solids"]:
        g = PARAMETER_GUIDELINES[feat]
        def_v = default_vals.get(feat, g["default"])
        val = float(def_v) if (def_v is not None and not np.isnan(def_v)) else g["default"]
        sample_data[feat] = st.number_input(f"{g['label']} ({g['unit']})", value=val, step=float(g['step']), key=f"risk_{feat}")

with p_col2:
    for feat in ["Chloramines", "Sulfate", "Conductivity"]:
        g = PARAMETER_GUIDELINES[feat]
        def_v = default_vals.get(feat, g["default"])
        val = float(def_v) if (def_v is not None and not np.isnan(def_v)) else g["default"]
        sample_data[feat] = st.number_input(f"{g['label']} ({g['unit']})", value=val, step=float(g['step']), key=f"risk_{feat}")

with p_col3:
    for feat in ["Organic_carbon", "Trihalomethanes", "Turbidity"]:
        g = PARAMETER_GUIDELINES[feat]
        def_v = default_vals.get(feat, g["default"])
        val = float(def_v) if (def_v is not None and not np.isnan(def_v)) else g["default"]
        sample_data[feat] = st.number_input(f"{g['label']} ({g['unit']})", value=val, step=float(g['step']), key=f"risk_{feat}")

# Run ML model & Risk engine
model_pred = WaterWatchPredictor.predict_sample(sample_data, "decision_tree")
risk_results = calculate_community_risk(sample_data, model_pred["prediction_class"], model_pred["prob_potable"])

st.markdown("<br>", unsafe_allow_html=True)
st.markdown("## 📋 Community Risk Assessment Report")

r1, r2, r3, r4 = st.columns(4)
with r1:
    render_metric_card("Community Risk Score", f"{risk_results['risk_score']}/100", "Composite WQI Index", risk_results['risk_level'], risk_results['risk_color'])
with r2:
    render_metric_card("ML Potability Prediction", model_pred["label"].split()[0], f"Probability: {model_pred['confidence']*100:.1f}%", "Decision Tree", "#1d3557")
with r3:
    render_metric_card("Critical Violations", str(risk_results['critical_violations']), "Severe parameter breaches", "Requires Action" if risk_results['critical_violations']>0 else "None", "#e63946" if risk_results['critical_violations']>0 else "#2a9d8f")
with r4:
    render_metric_card("Affected Population", f"{pop_served:,}", f"Location: {source_name}", "Community at Risk" if risk_results['risk_score']>40 else "Normal Status", "#f77f00")

st.markdown("<br>", unsafe_allow_html=True)

# Risk Gauge & Radar Chart
g_col, rad_col = st.columns([1, 1])
with g_col:
    st.plotly_chart(create_risk_gauge(risk_results["risk_score"], risk_results["risk_level"], risk_results["risk_color"]), use_container_width=True)
    st.markdown(
        f"""
        <div style="background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 15px; margin-top: 10px;">
            <h5 style="color: {risk_results['risk_color']}; margin-bottom: 6px;">📢 {risk_results['action_priority']}</h5>
            <p style="font-size: 0.92rem; color: #495057; margin-bottom: 0;">{risk_results['advisory']}</p>
        </div>
        """,
        unsafe_allow_html=True
    )

with rad_col:
    st.markdown("#### Parameter Compliance Profile vs WHO Baseline (100%)")
    st.plotly_chart(create_radar_chart(sample_data), use_container_width=True)

# Parameter Audit Table
st.markdown("### 🔍 Specific Parameter Exceedances & Remediation Directives")
table_rows = []
for a in risk_results["parameter_audits"]:
    p = a["parameter"]
    table_rows.append({
        "Parameter": f"{a['label']} ({a['unit']})",
        "Observed Value": a["value"],
        "WHO Limit": f"{PARAMETER_GUIDELINES[p]['min_safe']} – {PARAMETER_GUIDELINES[p]['max_safe']}",
        "Status": a["badge"],
        "Health Severity": f"Level {a['severity']}",
        "Engineering Remediation Action": a["remediation"]
    })

st.dataframe(pd.DataFrame(table_rows), use_container_width=True, hide_index=True)

# Printable Public Health Notice Generator
st.divider()
st.markdown("### 🖨️ Official Community Notice Generator")
st.caption("Generate an official printable public bulletin advisory for display at community distribution points.")

bulletin_text = f"""
================================================================================
OFFICIAL COMMUNITY DRINKING WATER QUALITY ADVISORY
================================================================================
Station Name: {source_name} ({source_type})
Population Impacted: {pop_served:,} Residents
Status Rating: {risk_results['risk_level']} (Composite Risk Index: {risk_results['risk_score']}/100)
ML Classification: {model_pred['label']} (Confidence: {model_pred['confidence']*100:.1f}%)

ACTION REQUIRED:
{risk_results['action_priority']}

PUBLIC HEALTH ADVISORY:
{risk_results['advisory']}

EXCEEDANCE DETAILS:
"""
for a in risk_results["parameter_audits"]:
    if a["violation"]:
        bulletin_text += f"- {a['label']}: {a['value']} {a['unit']} ({a['status']} — Recommended Action: {a['remediation']})\n"

bulletin_text += f"""
IMPORTANT DISCLAIMER:
WATERWATCH AI provides decision-support risk screening based on 9 continuous 
physicochemical indicators. Accredited laboratory microbiological testing 
(E. coli / Coliforms) and heavy metal assays are mandatory before water release.
================================================================================
"""

st.text_area("Notice Preview:", value=bulletin_text, height=260)
st.download_button(
    label="📥 Download Official Notice (.txt)",
    data=bulletin_text,
    file_name=f"Water_Advisory_{source_name.replace(' ', '_')}.txt",
    mime="text/plain"
)
