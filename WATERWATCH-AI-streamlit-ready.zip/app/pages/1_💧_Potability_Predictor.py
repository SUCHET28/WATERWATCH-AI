"""
WATERWATCH AI — Single Sample Potability Predictor
Interactive classification and water quality parameter verification.
"""

import sys
from pathlib import Path

# Add project root and app directory to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
APP_DIR = Path(__file__).resolve().parent.parent
for p in [str(ROOT_DIR), str(APP_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

import streamlit as st
import pandas as pd
import numpy as np

from src.data.loader import FEATURE_NAMES, PARAMETER_GUIDELINES, PRESET_SAMPLES
from src.models.predictor import WaterWatchPredictor, MODEL_METADATA
from src.risk_engine.risk_scorer import calculate_community_risk
from src.components.ui_elements import (
    render_disclaimer,
    create_radar_chart,
    create_risk_gauge,
    create_probability_bar
)

st.set_page_config(page_title="Potability Predictor — WATERWATCH AI", page_icon="💧", layout="wide")

st.markdown("# 💧 Water Potability Predictor")
st.markdown("Assess the drinking safety of a water sample using trained Scikit-Learn pipelines and WHO standards.")

render_disclaimer(compact=True)

# Preset Selection Row
col_preset, col_model = st.columns([2, 1])

with col_preset:
    preset_choice = st.selectbox(
        "⚡ Quick-Fill with Standard Presets:",
        options=["Custom User Input"] + list(PRESET_SAMPLES.keys()),
        index=0,
        help="Select a benchmark scenario to automatically populate parameter values."
    )

with col_model:
    model_choice = st.selectbox(
        "🤖 Select Classifier Architecture:",
        options=["decision_tree", "gaussian_nb", "compare_both"],
        format_func=lambda x: {
            "decision_tree": "Decision Tree (Accuracy: 63.11%)",
            "gaussian_nb": "Gaussian Naive Bayes (ROC-AUC: 0.6090)",
            "compare_both": "⚖️ Compare Both Models Side-by-Side"
        }.get(x, x),
        index=0
    )

# Determine default input values based on preset
default_values = {}
if preset_choice in PRESET_SAMPLES:
    default_values = PRESET_SAMPLES[preset_choice]

st.markdown("### 🧪 Input Water Quality Parameters")
st.caption("Adjust sliders or enter measured physicochemical values. Missing parameters will be automatically imputed by the pipeline's median imputer.")

# Form for 9 parameters organized into 3 columns
sample_inputs = {}

c1, c2, c3 = st.columns(3)

with c1:
    st.markdown("#### 1. Fundamental Chemistry")
    for feat in ["ph", "Hardness", "Solids"]:
        meta = PARAMETER_GUIDELINES[feat]
        val = default_values.get(feat, meta["default"])
        val_float = float(val) if (val is not None and not np.isnan(val)) else meta["default"]
        
        sample_inputs[feat] = st.number_input(
            label=f"{meta['label']} ({meta['unit']})",
            min_value=float(meta["min_limit"]),
            max_value=float(meta["max_limit"]),
            value=val_float,
            step=float(meta["step"]),
            help=f"{meta['desc']} WHO safe limit: {meta['min_safe']} – {meta['max_safe']} {meta['unit']}."
        )
        st.caption(f"WHO Standard: **{meta['min_safe']} – {meta['max_safe']} {meta['unit']}**")

with c2:
    st.markdown("#### 2. Disinfection & Minerals")
    for feat in ["Chloramines", "Sulfate", "Conductivity"]:
        meta = PARAMETER_GUIDELINES[feat]
        val = default_values.get(feat, meta["default"])
        # Allow simulating NaN / Missing value for Sulfate if preset specifies it
        is_preset_nan = (preset_choice in PRESET_SAMPLES and (val is None or np.isnan(val)))
        
        allow_nan = st.checkbox(f"Mark {feat} as Missing / Unmeasured", value=is_preset_nan, key=f"nan_{feat}") if feat == "Sulfate" else False
        
        if allow_nan:
            sample_inputs[feat] = np.nan
            st.info(f"ℹ️ {feat} will be automatically imputed by the pipeline imputer.")
        else:
            val_float = float(val) if (val is not None and not np.isnan(val)) else meta["default"]
            sample_inputs[feat] = st.number_input(
                label=f"{meta['label']} ({meta['unit']})",
                min_value=float(meta["min_limit"]),
                max_value=float(meta["max_limit"]),
                value=val_float,
                step=float(meta["step"]),
                help=f"{meta['desc']} Safe limit: ≤ {meta['max_safe']} {meta['unit']}."
            )
        st.caption(f"WHO Standard: **≤ {meta['max_safe']} {meta['unit']}**")

with c3:
    st.markdown("#### 3. Organic & Physical Quality")
    for feat in ["Organic_carbon", "Trihalomethanes", "Turbidity"]:
        meta = PARAMETER_GUIDELINES[feat]
        val = default_values.get(feat, meta["default"])
        val_float = float(val) if (val is not None and not np.isnan(val)) else meta["default"]

        sample_inputs[feat] = st.number_input(
            label=f"{meta['label']} ({meta['unit']})",
            min_value=float(meta["min_limit"]),
            max_value=float(meta["max_limit"]),
            value=val_float,
            step=float(meta["step"]),
            help=f"{meta['desc']} Safe limit: ≤ {meta['max_safe']} {meta['unit']}."
        )
        st.caption(f"WHO Standard: **≤ {meta['max_safe']} {meta['unit']}**")

st.markdown("<br>", unsafe_allow_html=True)
run_predict = st.button("🚀 Evaluate Water Potability & Risk", type="primary", use_container_width=True)

# Run Inference
if run_predict or preset_choice != "Custom User Input":
    st.divider()
    st.markdown("## 📊 Inference Results & Quality Audit")

    if model_choice == "compare_both":
        # Run both models side by side
        res_dt = WaterWatchPredictor.predict_sample(sample_inputs, "decision_tree")
        res_gnb = WaterWatchPredictor.predict_sample(sample_inputs, "gaussian_nb")

        col_dt, col_gnb = st.columns(2)
        with col_dt:
            st.markdown("### 🌳 Decision Tree Pipeline")
            if res_dt["is_potable"]:
                st.success(f"### ✅ POTABLE (Safe)\nConfidence: **{res_dt['prob_potable']*100:.1f}%**")
            else:
                st.error(f"### 🛑 NON-POTABLE (Unsafe)\nConfidence: **{res_dt['prob_non_potable']*100:.1f}%**")
            st.plotly_chart(create_probability_bar(res_dt["prob_potable"], res_dt["prob_non_potable"]), use_container_width=True)
            st.caption(f"Dangerous False Positive Risk: **{res_dt['dangerous_error_warning']}** on non-potables")

        with col_gnb:
            st.markdown("### 📈 Gaussian Naive Bayes Pipeline")
            if res_gnb["is_potable"]:
                st.success(f"### ✅ POTABLE (Safe)\nConfidence: **{res_gnb['prob_potable']*100:.1f}%**")
            else:
                st.error(f"### 🛑 NON-POTABLE (Unsafe)\nConfidence: **{res_gnb['prob_non_potable']*100:.1f}%**")
            st.plotly_chart(create_probability_bar(res_gnb["prob_potable"], res_gnb["prob_non_potable"]), use_container_width=True)
            st.caption(f"Dangerous False Positive Risk: **{res_gnb['dangerous_error_warning']}** on non-potables")

        # Primary risk evaluation based on Decision Tree
        active_res = res_dt
    else:
        active_res = WaterWatchPredictor.predict_sample(sample_inputs, model_choice)
        
        r_col1, r_col2 = st.columns([1, 2])
        with r_col1:
            if active_res["is_potable"]:
                st.markdown(
                    f"""
                    <div style="background-color: #e8f5e9; border: 2px solid #2e7d32; border-radius: 10px; padding: 20px; text-align: center;">
                        <h2 style="color: #1b5e20; margin-bottom: 5px;">✅ POTABLE</h2>
                        <h4 style="color: #2e7d32; font-weight: 500;">Preliminary Safe Rating</h4>
                        <p style="font-size: 1.1rem; font-weight: 700; color: #1b5e20;">Confidence: {active_res['prob_potable']*100:.1f}%</p>
                        <p style="font-size: 0.82rem; color: #388e3c;">Model: {active_res['model_used']}</p>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            else:
                st.markdown(
                    f"""
                    <div style="background-color: #ffebee; border: 2px solid #c62828; border-radius: 10px; padding: 20px; text-align: center;">
                        <h2 style="color: #b71c1c; margin-bottom: 5px;">🛑 NON-POTABLE</h2>
                        <h4 style="color: #c62828; font-weight: 500;">Unsafe for Consumption</h4>
                        <p style="font-size: 1.1rem; font-weight: 700; color: #b71c1c;">Confidence: {active_res['prob_non_potable']*100:.1f}%</p>
                        <p style="font-size: 0.82rem; color: #d32f2f;">Model: {active_res['model_used']}</p>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

        with r_col2:
            st.markdown("#### Class Probabilities Breakdown")
            st.plotly_chart(create_probability_bar(active_res["prob_potable"], active_res["prob_non_potable"]), use_container_width=True)
            if active_res["is_potable"]:
                st.warning(
                    f"⚠️ **Screening Alert:** Model produces a **{active_res['dangerous_error_warning']}** dangerous false-positive error rate on unsafe water. "
                    "Do not distribute for drinking without certified microbiological assays.",
                    icon="⚠️"
                )

    # Risk Engine Assessment
    risk_summary = calculate_community_risk(sample_inputs, active_res["prediction_class"], active_res["prob_potable"])

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("### 🛡️ Community Risk Index & Parameter Radar")

    col_gauge, col_radar = st.columns([1, 1])

    with col_gauge:
        st.plotly_chart(create_risk_gauge(risk_summary["risk_score"], risk_summary["risk_level"], risk_summary["risk_color"]), use_container_width=True)
        st.info(f"**Action Plan:** {risk_summary['action_priority']}\n\n**Advisory:** {risk_summary['advisory']}")

    with col_radar:
        st.markdown("#### Parameter Deviation from WHO Threshold (100% = Safe Maximum)")
        st.plotly_chart(create_radar_chart(sample_inputs), use_container_width=True)

    # Detailed Audit Table
    st.markdown("### 📋 Biochemical Parameter Audit Breakdown")
    audit_data = []
    for a in risk_summary["parameter_audits"]:
        param = a["parameter"]
        meta = PARAMETER_GUIDELINES[param]
        audit_data.append({
            "Parameter": f"{a['label']} ({meta['unit']})",
            "Current Value": a["value"],
            "WHO Safe Standard": f"{meta['min_safe']} – {meta['max_safe']}",
            "Status": a["badge"],
            "Diagnosis": a["message"],
            "Recommended Treatment": a["remediation"]
        })
    
    st.dataframe(pd.DataFrame(audit_data), use_container_width=True, hide_index=True)
