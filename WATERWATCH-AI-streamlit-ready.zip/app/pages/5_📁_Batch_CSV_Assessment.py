"""
WATERWATCH AI — Batch CSV Assessment & Screening Prioritization
Bulk inference, sensor batch upload, and downloadable priority reports.
"""

import sys
import io
from pathlib import Path

# Add project root and app directory to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
APP_DIR = Path(__file__).resolve().parent.parent
for p in [str(ROOT_DIR), str(APP_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px

from src.data.loader import FEATURE_NAMES, load_dataset
from src.models.predictor import WaterWatchPredictor, MODEL_METADATA
from src.components.ui_elements import render_metric_card, render_disclaimer

st.set_page_config(page_title="Batch CSV Assessment — WATERWATCH AI", page_icon="📁", layout="wide")

st.markdown("# 📁 Batch CSV Assessment & Triage Prioritization")
st.markdown("Upload batches of field samples or telemetry data to prioritize laboratory testing and identify contaminated sources.")

render_disclaimer(compact=True)

# Model selection & instructions
col_opt1, col_opt2 = st.columns([2, 1])

with col_opt1:
    st.markdown("#### Upload CSV File")
    uploaded_file = st.file_uploader(
        "Upload water samples CSV (must contain 9 physicochemical feature columns):",
        type=["csv"],
        help="Expected columns: ph, Hardness, Solids, Chloramines, Sulfate, Conductivity, Organic_carbon, Trihalomethanes, Turbidity."
    )

with col_opt2:
    selected_model = st.selectbox(
        "Classifier Pipeline:",
        options=["decision_tree", "gaussian_nb"],
        format_func=lambda x: MODEL_METADATA[x]["name"]
    )
    
    # Template CSV download
    template_df = pd.DataFrame([{feat: 0.0 for feat in FEATURE_NAMES}])
    template_csv = template_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download Template CSV",
        data=template_csv,
        file_name="waterwatch_batch_template.csv",
        mime="text/csv",
        help="Use this template to format your field data."
    )

# Demo button if no file uploaded
use_demo = False
if uploaded_file is None:
    st.info("💡 **Don't have a CSV right now?** Click below to run a batch assessment on a 25-sample test slice from the project dataset.")
    if st.button("🧪 Load 25-Sample Demonstration Slice", type="secondary"):
        use_demo = True

df_batch = None

if uploaded_file is not None:
    try:
        df_batch = pd.read_csv(uploaded_file)
    except Exception as e:
        st.error(f"Error parsing CSV file: {e}")
elif use_demo:
    df_raw = load_dataset()
    df_batch = df_raw.sample(n=25, random_state=42).copy()
    if "Potability" in df_batch.columns:
        # Keep ground truth for comparison if available
        ground_truth = df_batch["Potability"].copy()

if df_batch is not None:
    st.divider()
    st.markdown(f"### 🔍 Processing Batch ({len(df_batch)} Samples)")

    # Validate required columns
    missing_cols = [c for c in FEATURE_NAMES if c not in df_batch.columns]
    if missing_cols:
        st.error(f"❌ Uploaded CSV is missing required columns: {missing_cols}")
    else:
        # Run Batch Inference
        with st.spinner("Running batch inference through Scikit-Learn pipeline..."):
            results_df = WaterWatchPredictor.predict_batch(df_batch, selected_model)

        # Batch Metrics
        total_samples = len(results_df)
        unsafe_samples = (results_df["Predicted_Class"] == 0).sum()
        safe_samples = (results_df["Predicted_Class"] == 1).sum()
        unsafe_pct = (unsafe_samples / total_samples) * 100

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            render_metric_card("Total Samples", f"{total_samples:,}", "Batch Size", "100% Evaluated", "#457b9d")
        with m2:
            render_metric_card("Flagged Unsafe", f"{unsafe_samples:,}", f"{unsafe_pct:.1f}% of batch", "Priority Triage", "#e63946")
        with m3:
            render_metric_card("Passed Potable", f"{safe_samples:,}", f"{(safe_samples/total_samples)*100:.1f}% of batch", "Screening Pass", "#2a9d8f")
        with m4:
            high_conf_unsafe = (results_df["NonPotable_Probability"] >= 0.70).sum()
            render_metric_card("High-Confidence Unsafe", f"{high_conf_unsafe:,}", "P(Unsafe) ≥ 70%", "Immediate Action", "#f77f00")

        st.markdown("<br>", unsafe_allow_html=True)

        # Visualization
        col_chart_left, col_chart_right = st.columns(2)
        
        with col_chart_left:
            fig_pie = px.pie(
                results_df,
                names="Potability_Label",
                title="Batch Classification Breakdown",
                color="Potability_Label",
                color_discrete_map={"Potable": "#2a9d8f", "Non-Potable": "#e63946"},
                hole=0.4
            )
            fig_pie.update_layout(height=320, paper_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig_pie, use_container_width=True)

        with col_chart_right:
            fig_hist = px.histogram(
                results_df,
                x="NonPotable_Probability",
                nbins=20,
                title="Distribution of Non-Potable Probability Risk Scores",
                color_discrete_sequence=["#e76f51"]
            )
            fig_hist.update_layout(
                xaxis_title="Predicted Probability of Non-Potable (P(0))",
                yaxis_title="Sample Count",
                height=320,
                paper_bgcolor='rgba(0,0,0,0)'
            )
            st.plotly_chart(fig_hist, use_container_width=True)

        # Table with Filter
        st.markdown("### 📋 Detailed Predictions Table")
        filter_status = st.radio("Filter Table by Prediction:", ["All", "Only Non-Potable (Unsafe)", "Only Potable (Safe)"], horizontal=True)

        if filter_status == "Only Non-Potable (Unsafe)":
            display_df = results_df[results_df["Predicted_Class"] == 0]
        elif filter_status == "Only Potable (Safe)":
            display_df = results_df[results_df["Predicted_Class"] == 1]
        else:
            display_df = results_df

        st.dataframe(
            display_df.style.map(
                lambda val: "background-color: #ffebee; color: #b71c1c; font-weight: bold;" if val == "Non-Potable"
                else "background-color: #e8f5e9; color: #1b5e20; font-weight: bold;" if val == "Potable" else "",
                subset=["Potability_Label"]
            ),
            use_container_width=True
        )

        # Download Processed Results
        st.markdown("### 📥 Export Evaluated Batch Report")
        csv_export = results_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download Complete Assessment CSV (.csv)",
            data=csv_export,
            file_name=f"waterwatch_batch_assessment_{selected_model}.csv",
            mime="text/csv"
        )
