"""
WATERWATCH AI — Exploratory Data Analysis (EDA) Dashboard
Multivariate chemical distributions, missing value audit, and correlation dynamics.
"""

import sys
from pathlib import Path

# Add project root and app directory to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
APP_DIR = Path(__file__).resolve().parent.parent
for p in [str(ROOT_DIR), str(APP_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

from src.data.loader import load_dataset, FEATURE_NAMES, TARGET_COL, PARAMETER_GUIDELINES
from src.components.ui_elements import render_metric_card

st.set_page_config(page_title="EDA Dashboard — WATERWATCH AI", page_icon="📊", layout="wide")

st.markdown("# 📊 Exploratory Data Analysis & Chemical Profiles")
st.markdown("Comprehensive statistical audit of the 3,276 water quality records from Member 1's data engineering pipeline.")

@st.cache_data
def get_data():
    return load_dataset()

df = get_data()

# Summary Metrics Row
c1, c2, c3, c4 = st.columns(4)
with c1:
    render_metric_card("Total Samples", f"{len(df):,}", "0 duplicate records", "3,276 Cleaned", "#2a9d8f")
with c2:
    potable_count = (df[TARGET_COL] == 1).sum()
    render_metric_card("Potable Samples (1)", f"{potable_count:,}", f"{(potable_count/len(df))*100:.1f}% of dataset", "Minority Class", "#457b9d")
with c3:
    non_potable_count = (df[TARGET_COL] == 0).sum()
    render_metric_card("Non-Potable (0)", f"{non_potable_count:,}", f"{(non_potable_count/len(df))*100:.1f}% of dataset", "Majority Class", "#e63946")
with c4:
    missing_total = df.isna().sum().sum()
    render_metric_card("Missing Values", f"{missing_total:,}", "Sulfate, pH, Trihalomethanes", "Median Imputed", "#f77f00")

st.markdown("<br>", unsafe_allow_html=True)

# Tabs for Structured Exploration
tab_dist, tab_corr, tab_outliers, tab_gallery = st.tabs([
    "📈 Interactive Distributions",
    "🔥 Correlation Heatmap",
    "📐 Outlier & Missingness Audit",
    "🖼️ Member 1 Publication Gallery"
])

# ----------------- TAB 1: DISTRIBUTIONS -----------------
with tab_dist:
    st.markdown("### Interactive Feature Distributions by Potability Class")
    
    col_feat, col_type = st.columns([2, 1])
    with col_feat:
        selected_feat = st.selectbox(
            "Select Physicochemical Feature to Inspect:",
            options=FEATURE_NAMES,
            format_func=lambda x: f"{PARAMETER_GUIDELINES[x]['label']} ({PARAMETER_GUIDELINES[x]['unit']})"
        )
    with col_type:
        chart_type = st.radio("Chart Type:", ["Histogram & KDE", "Boxplot", "Violin Plot"], horizontal=True)

    meta = PARAMETER_GUIDELINES[selected_feat]
    
    # Plotly Visuals
    df_plot = df.copy()
    df_plot["Potability_Label"] = df_plot[TARGET_COL].map({0: "Non-Potable (0)", 1: "Potable (1)"})
    
    color_map = {"Non-Potable (0)": "#e63946", "Potable (1)": "#2a9d8f"}

    if chart_type == "Histogram & KDE":
        fig = px.histogram(
            df_plot,
            x=selected_feat,
            color="Potability_Label",
            barmode="overlay",
            marginal="box",
            opacity=0.6,
            color_discrete_map=color_map,
            title=f"Distribution of {meta['label']} by Potability Class"
        )
        # Add WHO guideline vertical line
        fig.add_vline(x=meta["max_safe"], line_dash="dash", line_color="orange", annotation_text=f"WHO Limit: {meta['max_safe']}")
    elif chart_type == "Boxplot":
        fig = px.box(
            df_plot,
            x="Potability_Label",
            y=selected_feat,
            color="Potability_Label",
            points="outliers",
            color_discrete_map=color_map,
            title=f"Boxplot Comparison of {meta['label']}"
        )
        fig.add_hline(y=meta["max_safe"], line_dash="dash", line_color="orange", annotation_text=f"WHO Limit: {meta['max_safe']}")
    else:
        fig = px.violin(
            df_plot,
            x="Potability_Label",
            y=selected_feat,
            color="Potability_Label",
            box=True,
            points="all",
            color_discrete_map=color_map,
            title=f"Violin Density Profile of {meta['label']}"
        )

    fig.update_layout(height=450, paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
    st.plotly_chart(fig, use_container_width=True)

    st.info(
        f"**Domain Takeaway:** {meta['desc']} Notice how the potable and non-potable density curves overlap almost completely. "
        "This empirical overlap demonstrates that water potability cannot be partitioned by single-parameter thresholds alone, "
        "necessitating multivariate machine learning models."
    )

# ----------------- TAB 2: CORRELATION HEATMAP -----------------
with tab_corr:
    st.markdown("### Feature Correlation Matrix")
    corr_matrix = df.corr()

    fig_corr = px.imshow(
        corr_matrix,
        text_auto=".2f",
        aspect="auto",
        color_continuous_scale="RdBu_r",
        zmin=-0.15,
        zmax=0.15,
        title="Pairwise Pearson Correlation Matrix (Including Potability)"
    )
    fig_corr.update_layout(height=520, paper_bgcolor='rgba(0,0,0,0)')
    st.plotly_chart(fig_corr, use_container_width=True)

    st.markdown(
        """
        > 💡 **Crucial Research Finding from Member 1:**
        > - All pairwise correlation coefficients between chemical features are near zero ($|r| < 0.08$).
        > - Correlation between any individual feature and `Potability` is similarly negligible ($|r| \\le 0.03$).
        > - **Implication:** Linear models (e.g., standard Logistic Regression or linear SVMs) struggle to draw high-confidence decision boundaries. Regularized decision trees and Bayesian estimators are specifically chosen to address non-linear interactions.
        """
    )

# ----------------- TAB 3: OUTLIERS & MISSINGNESS -----------------
with tab_outliers:
    st.markdown("### Missing Value Audit & IQR Outlier Analysis")

    col_miss, col_iqr = st.columns([1, 1])

    with col_miss:
        st.markdown("#### 1. Missing Value Quantification")
        missing_df = pd.DataFrame({
            "Feature": df.columns,
            "Missing Count": df.isna().sum(),
            "Missing Percentage (%)": np.round((df.isna().sum() / len(df)) * 100, 2)
        }).sort_values(by="Missing Count", ascending=False).reset_index(drop=True)

        st.dataframe(missing_df, use_container_width=True, hide_index=True)
        st.caption(
            "Missing values occur strictly across Sulfate (23.84%), pH (14.99%), and Trihalomethanes (4.95%). "
            "All remaining 6 features have 100% complete records."
        )

    with col_iqr:
        st.markdown("#### 2. IQR Outlier Investigation Decisions")
        outlier_data = [
            {"Feature": "ph", "IQR Bounds": "[3.14, 11.02]", "Outliers": 46, "Pct": "1.40%", "Action": "Retained"},
            {"Feature": "Hardness", "IQR Bounds": "[117.13, 276.39]", "Outliers": 83, "Pct": "2.53%", "Action": "Retained"},
            {"Feature": "Solids", "IQR Bounds": "[-1832, 44831]", "Outliers": 47, "Pct": "1.43%", "Action": "Retained"},
            {"Feature": "Chloramines", "IQR Bounds": "[3.15, 11.10]", "Outliers": 61, "Pct": "1.86%", "Action": "Retained"},
            {"Feature": "Sulfate", "IQR Bounds": "[229.32, 438.33]", "Outliers": 41, "Pct": "1.25%", "Action": "Retained"},
            {"Feature": "Conductivity", "IQR Bounds": "[191.65, 655.88]", "Outliers": 11, "Pct": "0.34%", "Action": "Retained"},
            {"Feature": "Organic_carbon", "IQR Bounds": "[5.33, 23.30]", "Outliers": 25, "Pct": "0.76%", "Action": "Retained"},
            {"Feature": "Trihalomethanes", "IQR Bounds": "[23.61, 109.58]", "Outliers": 33, "Pct": "1.01%", "Action": "Retained"},
            {"Feature": "Turbidity", "IQR Bounds": "[1.85, 6.09]", "Outliers": 20, "Pct": "0.61%", "Action": "Retained"}
        ]
        st.dataframe(pd.DataFrame(outlier_data), use_container_width=True, hide_index=True)
        st.caption(
            "**Scientific Justification for Retention:** In environmental hydrology, extreme readings represent genuine industrial discharge, "
            "mineral leaching, or severe contamination events. Truncating outliers would destroy the very hazardous signals an automated system must catch."
        )

# ----------------- TAB 4: PUBLICATION GALLERY -----------------
with tab_gallery:
    st.markdown("### Member 1 Publication-Quality Figures Gallery")
    st.markdown("These figures were generated and verified during Phase 1–4 of the experimental workflow (`results/figures/`).")

    fig_dir = ROOT_DIR / "results" / "figures"
    
    figures_info = [
        ("01_target_class_distribution.png", "Figure 1: Target Class Distribution (60.99% Non-Potable vs 39.01% Potable)"),
        ("02_feature_histograms.png", "Figure 2: Multivariate Feature Histograms Across Continuous Biochemical Dimensions"),
        ("03_numerical_boxplots.png", "Figure 3: Numerical Boxplots and Statistical Outlier Spreads"),
        ("04_correlation_heatmap.png", "Figure 4: Inter-Feature Correlation Heatmap Showing Negligible Linear Associations"),
        ("05_class_comparison_kde.png", "Figure 5: Kernel Density Estimation (KDE) Class Comparison Plots"),
        ("06_missing_values_matrix.png", "Figure 6: Missing Values Matrix Audit (MCAR Distribution)")
    ]

    for filename, caption in figures_info:
        img_path = fig_dir / filename
        if img_path.exists():
            st.image(str(img_path), caption=caption, use_container_width=True)
            st.markdown("<hr style='margin: 1.5rem 0;'>", unsafe_allow_html=True)
        else:
            st.warning(f"Figure file not found: {filename}")
