"""
WATERWATCH AI — Main Entry Point
Explainable AI-Based Water Potability Prediction and Community Risk Monitoring System
"""

import sys
from pathlib import Path

# Add project root and app directory to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
APP_DIR = Path(__file__).resolve().parent
for p in [str(ROOT_DIR), str(APP_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

import streamlit as st
import pandas as pd
from src.data.loader import FEATURE_NAMES, PARAMETER_GUIDELINES
from src.models.predictor import MODEL_METADATA, WaterWatchPredictor
from src.components.ui_elements import render_disclaimer, render_metric_card

st.set_page_config(
    page_title="WATERWATCH AI — Water Potability & Risk System",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load custom CSS
css_file = ROOT_DIR / "app" / "assets" / "style.css"
if css_file.exists():
    with open(css_file, "r", encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/water.png", width=64)
    st.markdown("## **WATERWATCH AI**")
    st.markdown(
        "*Explainable AI-Based Water Potability Prediction & Community Risk Monitoring System*"
    )
    st.divider()

    st.markdown("### 📌 Navigation")
    st.info(
        "Use the pages above or in the sidebar to access:\n"
        "- 💧 **Potability Predictor**\n"
        "- 📊 **Exploratory Data Analysis**\n"
        "- 🤖 **Model Benchmark & Audit**\n"
        "- 🛡️ **Community Risk Engine**\n"
        "- 📁 **Batch CSV Assessment**"
    )

    st.divider()
    st.markdown("### 👥 Team Contribution")
    st.caption("**Member 1:** Data Engineering, EDA, Preprocessing & ML Pipelines")
    st.caption("**Member 3:** Application Architecture, Streamlit Dashboard & XAI UI")
    st.divider()
    st.markdown("### 🔬 Standard References")
    st.caption("• WHO Guidelines for Drinking-Water Quality (4th ed.)\n• US EPA National Primary Drinking Water Regulations")


# Hero Section
st.markdown(
    """
    <div class="waterwatch-hero">
        <h1>💧 WATERWATCH AI</h1>
        <p>
            An explainable machine learning decision-support platform designed to predict water potability from continuous
            physicochemical parameters, benchmark supervised classifiers, and audit community contamination risk for public health protection.
        </p>
        <div class="hero-tags">
            <span class="hero-badge">🌿 Scikit-Learn Leakage-Free Pipelines</span>
            <span class="hero-badge">🌳 Decision Tree & Gaussian Naive Bayes</span>
            <span class="hero-badge">🛡️ Community Risk Index (WQI)</span>
            <span class="hero-badge">⚠️ False-Positive Error Auditing</span>
            <span class="hero-badge">🧪 WHO / EPA Water Standards</span>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

# Mandatory Disclaimer
render_disclaimer(compact=False)

# Key System Metrics Row
st.markdown("### 📈 Core System & Benchmark Metrics")
m1, m2, m3, m4 = st.columns(4)

with m1:
    render_metric_card(
        title="Evaluated Dataset",
        value="3,276",
        subtext="Water samples (0 duplicates)",
        delta="80/20 Stratified Split",
        delta_color="#457b9d"
    )

with m2:
    render_metric_card(
        title="Physicochemical Features",
        value="9",
        subtext="pH, Hardness, TDS, Chloramines...",
        delta="Continuous float64",
        delta_color="#2a9d8f"
    )

with m3:
    render_metric_card(
        title="Top Accuracy (Decision Tree)",
        value="63.11%",
        subtext="5-Fold CV: 62.98% ± 0.95%",
        delta="+2.13% vs Naive Baseline",
        delta_color="#2a9d8f"
    )

with m4:
    render_metric_card(
        title="Top ROC-AUC (Gaussian NB)",
        value="0.6090",
        subtext="Held-out 656 test samples",
        delta="Screening Baseline: 0.5000",
        delta_color="#e76f51"
    )

st.markdown("<br>", unsafe_allow_html=True)

# Architecture & Workflow
st.markdown("### 🏛️ System Architecture & Workflow")

col_left, col_right = st.columns([3, 2])

with col_left:
    st.markdown(
        """
        The **WATERWATCH AI** architecture is structured into four integrated tiers:
        
        1. **Data Engineering Tier (Member 1):**
           - Raw data validation across 3,276 records (`water_potability.csv`).
           - Outlier retention justified by physical environmental contamination signals.
           - Scikit-Learn median imputation and standardization sealed inside training pipelines to guarantee zero data leakage.
        
        2. **Machine Learning Tier (Member 1 & 2):**
           - **Baseline:** `DummyClassifier(strategy='most_frequent')` (Majority class guessing).
           - **Probabilistic:** `GaussianNB` (Optimal for continuous bell-curve chemical distributions).
           - **Rule-Based:** Regularized `DecisionTreeClassifier(max_depth=6, min_samples_leaf=10)`.
           - 5-Fold Stratified Cross-Validation strictly on training split.
        
        3. **App Architecture & Dashboard (Member 3):**
           - Streamlit multi-page interface for single sample testing, live batch CSV scoring, and EDA analysis.
           - Interactive Plotly visualizations for multivariate chemical distributions and radar compliance charts.
        
        4. **Community Risk & Decision-Support Engine:**
           - Weighted Water Quality Index (WQI) integrating chemical parameter limits with model probabilities.
           - Automated priority classifications and remediation directives (chlorination, RO, lime neutralization).
        """
    )

with col_right:
    st.info("### ⚠️ Public Health Screening Alert")
    st.markdown(
        """
        In water quality screening, **False Positives** (actual non-potable water predicted as potable) 
        represent the **critical dangerous error**.
        
        - **Gaussian Naive Bayes:** 45 dangerous errors (11.25% error rate on unsafe samples).
        - **Decision Tree:** 53 dangerous errors (13.25% error rate on unsafe samples).
        - **Dummy Classifier:** 0 false positives only because it flags *100% of samples as unsafe* (0% sensitivity).
        
        *WATERWATCH AI enforces secondary rule checks and alerts operators whenever a sample exhibits extreme single-parameter toxicity.*
        """
    )

st.divider()

# Quick Navigation Grid
st.markdown("### 🚀 Application Modules")

c1, c2, c3 = st.columns(3)
with c1:
    st.markdown(
        """
        <div style="border: 1px solid #ced4da; border-radius: 10px; padding: 18px; min-height: 180px; background: white;">
            <h4>💧 1. Potability Predictor</h4>
            <p style="color: #6c757d; font-size: 0.9rem;">
                Test single water samples using interactive sliders or preset contaminated/clean scenarios. Compare predictions across models in real time.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Open Potability Predictor ➡️", key="btn_nav_pred"):
        st.switch_page("pages/1_💧_Potability_Predictor.py")

with c2:
    st.markdown(
        """
        <div style="border: 1px solid #ced4da; border-radius: 10px; padding: 18px; min-height: 180px; background: white;">
            <h4>📊 2. Exploratory Data Analysis</h4>
            <p style="color: #6c757d; font-size: 0.9rem;">
                Explore distributions, correlation matrices, boxplots, and publication-quality figures documenting the 3,276 water records.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Open EDA Dashboard ➡️", key="btn_nav_eda"):
        st.switch_page("pages/2_📊_Exploratory_Data_Analysis.py")

with c3:
    st.markdown(
        """
        <div style="border: 1px solid #ced4da; border-radius: 10px; padding: 18px; min-height: 180px; background: white;">
            <h4>🤖 3. Model Benchmark & Audit</h4>
            <p style="color: #6c757d; font-size: 0.9rem;">
                Audit confusion matrices, ROC-AUC curves, cross-validation metrics, and the dangerous screening false-positive error audit.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Open Benchmark Audit ➡️", key="btn_nav_audit"):
        st.switch_page("pages/3_🤖_Model_Benchmark_&_Audit.py")

st.markdown("<br>", unsafe_allow_html=True)
c4, c5, _ = st.columns(3)

with c4:
    st.markdown(
        """
        <div style="border: 1px solid #ced4da; border-radius: 10px; padding: 18px; min-height: 180px; background: white;">
            <h4>🛡️ 4. Community Risk Engine</h4>
            <p style="color: #6c757d; font-size: 0.9rem;">
                Calculate multi-parameter Water Quality Index (WQI), threshold compliance radar charts, and municipal treatment advisories.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Open Risk Engine ➡️", key="btn_nav_risk"):
        st.switch_page("pages/4_🛡️_Community_Risk_Engine.py")

with c5:
    st.markdown(
        """
        <div style="border: 1px solid #ced4da; border-radius: 10px; padding: 18px; min-height: 180px; background: white;">
            <h4>📁 5. Batch CSV Assessment</h4>
            <p style="color: #6c757d; font-size: 0.9rem;">
                Upload municipal or field sensor batches for bulk inference, screening prioritization, and downloadable summary reports.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Open Batch Assessment ➡️", key="btn_nav_batch"):
        st.switch_page("pages/5_📁_Batch_CSV_Assessment.py")
