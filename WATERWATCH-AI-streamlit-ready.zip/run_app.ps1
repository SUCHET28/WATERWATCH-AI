﻿# Launch script for WATERWATCH AI Streamlit application
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "💧 Launching WATERWATCH AI Streamlit Application..." -ForegroundColor Green
Write-Host "===================================================" -ForegroundColor Cyan
python -m streamlit run app/app.py
