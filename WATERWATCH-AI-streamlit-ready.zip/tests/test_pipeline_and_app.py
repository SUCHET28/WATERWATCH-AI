"""
Unit and integration test suite for WATERWATCH AI.
Verifies data loading, model inference, risk engine scoring, and schema compliance.
"""

import sys
from pathlib import Path
import unittest
import numpy as np
import pandas as pd

# Add project root to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from src.data.loader import (
    load_dataset,
    FEATURE_NAMES,
    TARGET_COL,
    PARAMETER_GUIDELINES,
    PRESET_SAMPLES
)
from src.models.predictor import WaterWatchPredictor, MODEL_METADATA
from src.risk_engine.risk_scorer import (
    audit_parameter,
    calculate_community_risk
)


class TestWaterWatchAI(unittest.TestCase):
    """Test suite for core system capabilities."""

    def test_01_dataset_schema(self):
        """Verifies dataset has 3,276 samples and expected 10 columns."""
        df = load_dataset()
        self.assertEqual(len(df), 3276, "Dataset must have exactly 3,276 records.")
        for col in FEATURE_NAMES:
            self.assertIn(col, df.columns, f"Feature '{col}' missing from dataset.")
        self.assertIn(TARGET_COL, df.columns, f"Target column '{TARGET_COL}' missing.")
        self.assertEqual(df.duplicated().sum(), 0, "Dataset must contain 0 duplicates.")

    def test_02_decision_tree_pipeline_inference(self):
        """Verifies Decision Tree pipeline loads and produces valid predictions."""
        sample = PRESET_SAMPLES["🌱 Clean Municipal Tap Water (Normal)"]
        res = WaterWatchPredictor.predict_sample(sample, "decision_tree")
        self.assertIn(res["prediction_class"], [0, 1])
        self.assertGreaterEqual(res["prob_potable"], 0.0)
        self.assertLessEqual(res["prob_potable"], 1.0)
        self.assertAlmostEqual(res["prob_potable"] + res["prob_non_potable"], 1.0, places=4)

    def test_03_gaussian_nb_pipeline_inference(self):
        """Verifies Gaussian Naive Bayes pipeline loads and produces valid predictions."""
        sample = PRESET_SAMPLES["⚠️ High Sulfate & Mineral Contamination"]
        res = WaterWatchPredictor.predict_sample(sample, "gaussian_nb")
        self.assertIn(res["prediction_class"], [0, 1])
        self.assertGreaterEqual(res["prob_potable"], 0.0)
        self.assertLessEqual(res["prob_potable"], 1.0)

    def test_04_missing_value_imputation_safety(self):
        """Verifies pipeline safely handles missing (NaN) values without crashing."""
        sample_nan = {
            "ph": np.nan,
            "Hardness": 200.0,
            "Solids": 18000.0,
            "Chloramines": np.nan,
            "Sulfate": np.nan,
            "Conductivity": 400.0,
            "Organic_carbon": 14.0,
            "Trihalomethanes": 60.0,
            "Turbidity": 3.8
        }
        res_dt = WaterWatchPredictor.predict_sample(sample_nan, "decision_tree")
        self.assertIn(res_dt["prediction_class"], [0, 1])
        
        res_gnb = WaterWatchPredictor.predict_sample(sample_nan, "gaussian_nb")
        self.assertIn(res_gnb["prediction_class"], [0, 1])

    def test_05_community_risk_scoring(self):
        """Verifies risk engine produces valid composite score and alert priority."""
        sample = PRESET_SAMPLES["☢️ Acidic Runoff with High Organic Matter"]
        risk = calculate_community_risk(sample, model_prediction=0, prob_potable=0.15)
        self.assertGreaterEqual(risk["risk_score"], 0.0)
        self.assertLessEqual(risk["risk_score"], 100.0)
        self.assertEqual(risk["risk_level"], "CRITICAL RISK")
        self.assertGreater(risk["critical_violations"], 0)

    def test_06_batch_prediction_shape(self):
        """Verifies batch inference appends expected prediction and probability columns."""
        df = load_dataset().head(15)
        batch_res = WaterWatchPredictor.predict_batch(df, "decision_tree")
        self.assertEqual(len(batch_res), 15)
        self.assertIn("Predicted_Class", batch_res.columns)
        self.assertIn("Potability_Label", batch_res.columns)
        self.assertIn("Potable_Probability", batch_res.columns)
        self.assertIn("NonPotable_Probability", batch_res.columns)


if __name__ == "__main__":
    unittest.main()
